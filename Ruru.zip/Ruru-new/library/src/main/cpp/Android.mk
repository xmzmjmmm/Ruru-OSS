LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := applist_detector
LOCAL_SRC_FILES := src/environment.cpp \
                   src/file_detection.cpp \
                   src/time_sidechannel_detector.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/include
LOCAL_CPP_FEATURES := exceptions rtti
LOCAL_CFLAGS := -O2 -fvisibility=hidden
LOCAL_LDFLAGS := -Wl,--exclude-libs,ALL
LOCAL_SHARED_LIBRARIES := xposed-detector

include $(BUILD_SHARED_LIBRARY)

$(call import-add-path,$(NDK_GRADLE_INJECTED_IMPORT_PATH))
$(call import-module,xposed-detector)
