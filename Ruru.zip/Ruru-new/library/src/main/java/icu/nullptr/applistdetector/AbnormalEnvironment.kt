package icu.nullptr.applistdetector

import android.content.Context
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import androidx.annotation.Keep
import icu.nullptr.applistdetector.library.R

@Keep
class AbnormalEnvironment(
    override val context: Context,
    override val name: String
) : IDetector(context) {

    @Keep private external fun detectXposed(): Boolean
    @Keep private external fun detectClassLoaderCount(): Int
    @Keep private external fun checkEffectiveSu(): Int
    @Keep private external fun detectMountConflict(): Boolean
    @Keep private external fun detectZygiskNext(): Boolean
    @Keep private external fun detectLSPlant(): Boolean
    @Keep private external fun detectHMA(): Boolean
    @Keep private external fun detectSELinux(): Boolean
    @Keep private external fun detectMemoryDirty(): Boolean
    @Keep private external fun detectSyscallTampering(): Boolean

    private fun detectHMABinder(): Boolean {
        return try {
            val smClass = Class.forName("android.os.ServiceManager")
            val getServiceMethod = smClass.getMethod("getService", String::class.java)
            val binder = getServiceMethod.invoke(null, "package") as android.os.IBinder
            val data = android.os.Parcel.obtain()
            val reply = android.os.Parcel.obtain()
            try {
                data.writeInterfaceToken("android.content.pm.IPackageManager")
                binder.transact(0x484D4144, data, reply, 0)
                val hmaBinder = reply.readStrongBinder()
                hmaBinder != null
            } finally {
                data.recycle()
                reply.recycle()
            }
        } catch (e: Throwable) {
            false
        }
    }

    private fun detectAccessibilityFiltering(): Boolean {
        return try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            val enabledList = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            val enabledPackages = enabledList?.map { it.resolveInfo.serviceInfo.packageName }?.toSet() ?: emptySet()

            val settingValue = android.provider.Settings.Secure.getString(context.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            if (settingValue.isNullOrEmpty()) return false

            val settingPackages = settingValue.split(':').filter { it.contains('/') }.map { it.split('/')[0] }.toSet()

            settingPackages.any { it.isNotEmpty() && !enabledPackages.contains(it) }
        } catch (e: Throwable) {
            false
        }
    }

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        var result = Result.NOT_FOUND
        val add: (Pair<String, Result>) -> Unit = { detail?.add(it) }

        if (detectSyscallTampering()) {
            result = maxOf(result, Result.FOUND)
            add("检测到 Hook 篡改 / HMA" to Result.FOUND)
        }

        val clCount = detectClassLoaderCount()
        if (clCount > 8) {
            result = maxOf(result, Result.FOUND)
            add("检测到 LSPosed/Zygisk 注入 (CL 计数: $clCount)" to Result.FOUND)
        }

        if (detectMemoryDirty()) {
            result = maxOf(result, Result.FOUND)
            add("疑似 Zygisk/Shamiko" to Result.FOUND)
        }

        if (checkEffectiveSu() == 1) {
            result = maxOf(result, Result.FOUND)
            add(context.getString(R.string.l_su_valid) to Result.FOUND)
        }

        if (detectXposed()) {
            result = maxOf(result, Result.FOUND)
            add(context.getString(R.string.l_xp_active) to Result.FOUND)
        }

        if (detectMountConflict()) {
            result = maxOf(result, Result.FOUND)
            add("挂载冲突 (系统分区被篡改)" to Result.FOUND)
        }

        if (detectZygiskNext()) {
            result = maxOf(result, Result.FOUND)
            add("ZygiskNext / TrickyStore 痕迹" to Result.FOUND)
        }

        if (detectHMA()) {
            result = maxOf(result, Result.FOUND)
            add("检测到 HMA (SVC 一致性校验)" to Result.FOUND)
        }
        if (detectHMABinder()) {
            result = maxOf(result, Result.FOUND)
            add("检测到 HMA 服务 Binder (HMAD 协议)" to Result.FOUND)
        }
        if (detectAccessibilityFiltering()) {
            result = maxOf(result, Result.FOUND)
            add("无障碍服务被过滤 (疑似 HMA/Shamiko)" to Result.FOUND)
        }

        if (detectSELinux()) {
            result = maxOf(result, Result.FOUND)
            add("SELinux 宽容模式" to Result.FOUND)
        }

        return result
    }
}
