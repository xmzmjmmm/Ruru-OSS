plugins {
    id("com.android.application") version "8.2.2" apply false
    id("com.android.library") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}

val verCode by extra(21)
var verName by extra("1.4.1")

val minSdkVer by extra(24)
val targetSdkVer by extra(34)
val compileSdkVer by extra(34)
val ndkVer by extra("25.0.8775105")
val javaVer by extra(JavaVersion.VERSION_17)

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
