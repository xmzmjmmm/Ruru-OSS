#pragma once

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    NO_XPOSED,
    FOUND_XPOSED,
    ANTIED_XPOSED,
    CAN_NOT_ANTI_XPOSED,
};

int get_xposed_status(JNIEnv *env, int sdk);

#ifdef __cplusplus
}
#endif
