#include <jni.h>
#include <string>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <android/api-level.h>
#include <xposed-detector.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>

extern "C" {

#if defined(__aarch64__)
#define AT_FDCWD -100
static inline long raw_svc_access(const char* path, int mode) {
    register long x0 __asm__("x0") = (long)AT_FDCWD;
    register long x1 __asm__("x1") = (long)path;
    register long x2 __asm__("x2") = (long)mode;
    register long x8 __asm__("x8") = 48;
    __asm__ __volatile__("svc 0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x8) : "memory");
    return x0;
}
static inline long raw_svc_openat(const char* path, int flags) {
    register long x0 __asm__("x0") = (long)AT_FDCWD;
    register long x1 __asm__("x1") = (long)path;
    register long x2 __asm__("x2") = (long)flags;
    register long x3 __asm__("x3") = 0;
    register long x8 __asm__("x8") = 56;
    __asm__ __volatile__("svc 0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x3), "r"(x8) : "memory");
    return x0;
}
static inline long raw_svc_read(int fd, void* buf, size_t count) {
    register long x0 __asm__("x0") = (long)fd;
    register long x1 __asm__("x1") = (long)buf;
    register long x2 __asm__("x2") = (long)count;
    register long x8 __asm__("x8") = 63;
    __asm__ __volatile__("svc 0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x8) : "memory");
    return x0;
}
static inline long raw_svc_close(int fd) {
    register long x0 __asm__("x0") = (long)fd;
    register long x8 __asm__("x8") = 57;
    __asm__ __volatile__("svc 0" : "=r"(x0) : "r"(x0), "r"(x8) : "memory");
    return x0;
}
#else
#define raw_svc_access access
#define raw_svc_openat(p, f) open(p, f)
#define raw_svc_read read
#define raw_svc_close close
#endif

static bool IsAddressReadable(void* addr) {
    if (!addr) return false;
    static size_t page_size = getpagesize();
    unsigned char vec = 0;
    uintptr_t align_addr = (uintptr_t)addr & ~(page_size - 1);
    return mincore((void*)align_addr, page_size, &vec) == 0 && (vec & 1);
}

static int get_private_dirty(const char* target_so) {
    int fd = raw_svc_openat("/proc/self/smaps", O_RDONLY);
    if (fd < 0) return 0;
    char line[512];
    int total_dirty = 0;
    bool is_executable_segment = false;
    char c;
    int pos = 0;
    while (raw_svc_read(fd, &c, 1) == 1) {
        if (c == '\n' || pos >= 511) {
            line[pos] = 0;
            if (strstr(line, "r-xp") || strstr(line, "rwxp")) {
                is_executable_segment = true;
            } else if (strstr(line, "-p")) {
                if (!strstr(line, target_so)) {
                   is_executable_segment = false;
                }
            }

            if (is_executable_segment && strstr(line, "Private_Dirty:")) {
                char* p = strstr(line, "Private_Dirty:");
                if (p) total_dirty += atoi(p + 14);
            }
            pos = 0;
        } else {
            line[pos++] = c;
        }
    }
    raw_svc_close(fd);
    return total_dirty;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectSyscallTampering(JNIEnv* env, jobject thiz) {
    const char* target = "/proc/self/maps";
    int libc_res = access(target, F_OK);
    long svc_res = raw_svc_access(target, F_OK);
    if (libc_res != 0 && svc_res == 0) return JNI_TRUE;
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectClassLoaderCount(JNIEnv* env, jobject thiz) {
    JavaVM* vm = nullptr;
    env->GetJavaVM(&vm);
    if (!vm) return -1;
    void* runtime = *((void**)((uintptr_t)vm + sizeof(void*)));
    if (!IsAddressReadable(runtime)) return -1;

    void* handle = dlopen("libart.so", RTLD_NOW);
    if (handle) {
        void* sym = dlsym(handle, "_ZN3art11ClassLinker14class_loaders_E");
        if (sym) {
            void** vector_ptrs = (void**)sym;
            uintptr_t start = (uintptr_t)vector_ptrs[0];
            uintptr_t end = (uintptr_t)vector_ptrs[1];
            if (end > start) {
                return (int)((end - start) / sizeof(void*));
            }
        }
        dlclose(handle);
    }
    return 1;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectHMA(JNIEnv* env, jobject thiz) {
    const char* hma_traces[] = {
        "com.tsng.hidemyapplist",
        "icu.nullptr.hidemyapplist",
        "org.frknkrc44.hma_oss",
        "com.pittvandewitt.hideir"
    };
    for (const char* pkg : hma_traces) {
        std::string path = "/data/data/" + std::string(pkg);
        int libc_res = access(path.c_str(), F_OK);
        long svc_res = raw_svc_access(path.c_str(), F_OK);

        if (libc_res != 0 && svc_res == -13) return JNI_TRUE;
        if (svc_res == 0) return JNI_TRUE;
    }

    if (raw_svc_access("/data/system/hma_config", F_OK) == -13) return JNI_TRUE;

    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectZygiskNext(JNIEnv* env, jobject thiz) {
    if (raw_svc_access("/data/adb/zygisksu", F_OK) == 0) return JNI_TRUE;
    if (raw_svc_access("/data/adb/service.d/.zn_cleanup.sh", F_OK) == 0) return JNI_TRUE;

    int fd = raw_svc_openat("/proc/self/maps", O_RDONLY);
    if (fd >= 0) {
        char line[512];
        char c;
        int pos = 0;
        while (raw_svc_read(fd, &c, 1) == 1) {
            if (c == '\n' || pos >= 511) {
                line[pos] = 0;
                if (strstr(line, "memfd:zygisk-next") || strstr(line, "memfd:tricky-store")) {
                    raw_svc_close(fd);
                    return JNI_TRUE;
                }
                pos = 0;
            } else {
                line[pos++] = c;
            }
        }
        raw_svc_close(fd);
    }
    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectMemoryDirty(JNIEnv* env, jobject thiz) {
    if (get_private_dirty("libart.so") > 0) return JNI_TRUE;
    if (get_private_dirty("libandroid_runtime.so") > 0) return JNI_TRUE;
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_checkEffectiveSu(JNIEnv* env, jobject thiz) {
    if (raw_svc_access("/system/bin/su", F_OK) == 0) return 1;
    if (raw_svc_access("/system/xbin/su", F_OK) == 0) return 1;
    return 0;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectXposed(JNIEnv* env, jobject thiz) {
    return get_xposed_status(env, android_get_device_api_level()) != NO_XPOSED;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectLSPlant(JNIEnv* env, jobject thiz) {
    int fd = raw_svc_openat("/proc/self/maps", O_RDONLY);
    if (fd < 0) return JNI_FALSE;
    char line[512];
    char c;
    int pos = 0;
    bool found = false;
    while (raw_svc_read(fd, &c, 1) == 1) {
        if (c == '\n' || pos >= 511) {
            line[pos] = 0;
            if (strstr(line, "liblsplant.so")) {
                found = true;
                break;
            }
            pos = 0;
        } else {
            line[pos++] = c;
        }
    }
    raw_svc_close(fd);
    return found;
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectMountConflict(JNIEnv* env, jobject thiz) {
    int fd = raw_svc_openat("/proc/self/mountinfo", O_RDONLY);
    if (fd < 0) return JNI_FALSE;
    char line[512];
    char c;
    int pos = 0;
    int system_mounts = 0;
    bool found_adb_modules = false;
    while (raw_svc_read(fd, &c, 1) == 1) {
        if (c == '\n' || pos >= 511) {
            line[pos] = 0;
            if (strstr(line, " /system ")) system_mounts++;
            if (strstr(line, "/data/adb/modules")) found_adb_modules = true;
            pos = 0;
        } else {
            line[pos++] = c;
        }
    }
    raw_svc_close(fd);
    return (system_mounts > 1 || found_adb_modules);
}

JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_AbnormalEnvironment_detectSELinux(JNIEnv* env, jobject thiz) {
    int fd = raw_svc_openat("/sys/fs/selinux/enforce", O_RDONLY);
    if (fd < 0) return JNI_FALSE;
    char val;
    if (raw_svc_read(fd, &val, 1) == 1) {
        raw_svc_close(fd);
        return val == '0';
    }
    raw_svc_close(fd);
    return JNI_FALSE;
}

}
