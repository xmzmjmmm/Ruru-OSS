-keep class com.tencent.soter.** { *; }
-keep interface com.tencent.soter.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class icu.nullptr.applistdetector.** { *; }
