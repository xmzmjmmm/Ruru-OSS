package com.byxiaorun.detector

import android.accessibilityservice.AccessibilityServiceInfo
import android.accounts.AccountManager
import android.content.Context.CONNECTIVITY_SERVICE
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import com.byxiaorun.detector.MyApplication.Companion.accountList
import com.byxiaorun.detector.MyApplication.Companion.appContext
import com.byxiaorun.detector.MyApplication.Companion.vpn_connect
import icu.nullptr.applistdetector.MainPage
import icu.nullptr.applistdetector.theme.MyTheme
import java.io.*
import java.net.NetworkInterface

class MainActivity : ComponentActivity() {

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkDisabled()
        checkSetting()
        Accounts()
        setContent {
            MyTheme {
                Scaffold(
                    topBar = { MainTopBar() }
                ) { innerPadding ->
                    MainPage(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainTopBar() {
    TopAppBar(
        title = {
            Text(
                text = stringResource(id = R.string.app_name),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold
                )
            )
        }
    )
}

fun checkDisabled() {
    MyApplication.accList = getFromAccessibilityManager()+ getFromSettingsSecure()
}

private fun getFromAccessibilityManager(): List<String> {
        val accessibilityManager =
            ContextCompat.getSystemService(appContext, AccessibilityManager::class.java)
                ?: error("unreachable")
        val serviceList: List<AccessibilityServiceInfo> =
            accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                ?: emptyList()
        val nameList = serviceList.map {
            appContext.packageManager.getApplicationLabel(it.resolveInfo.serviceInfo.applicationInfo)
                .toString()
        }.toMutableList()
        if (accessibilityManager.isEnabled) {
            nameList.add("AccessibilityManager.isEnabled")
        }
        if (accessibilityManager.isTouchExplorationEnabled) {
            nameList.add("AccessibilityManager.isTouchExplorationEnabled")
        }
        return nameList
}

private fun getFromSettingsSecure():List<String> {
    try {
        val settingValue= Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        val nameList=if (settingValue.isNullOrEmpty()){
            emptyList()
        }else{
            settingValue.split(':')
        }.toMutableList()
        val enabled = Settings.Secure.getInt(appContext.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED)
        if (enabled != 0) {
            MyApplication.accenable =true
        }
        return nameList
    }catch (e:Settings.SettingNotFoundException){
        return emptyList()
    }
}

fun checkSetting() {
    if((Settings.Secure.getInt(appContext.contentResolver,Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,0)==1)){ MyApplication.development_enable=true }
    if((Settings.Secure.getInt(appContext.contentResolver,Settings.Global.ADB_ENABLED,0)==1)){ MyApplication.adbenable=true }

    try {
        vpn_connect = NetworkInterface.getNetworkInterfaces()?.toList()?.any { it.isUp && it.interfaceAddresses.isNotEmpty() && (it.name == "tun0" || it.name == "ppp0") } == true ||
                (appContext.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).getNetworkInfo(17)?.isConnectedOrConnecting == true ||
                (!System.getProperty("http.proxyHost").isNullOrEmpty() && (System.getProperty("http.proxyPort")?.toIntOrNull() ?: -1) != -1)
    } catch (e: Throwable) { e.printStackTrace() }
}

fun Accounts() {
    try{
        accountList= listOf()
        val accounts = AccountManager.get(appContext).getAccounts()
        var mutableList: MutableList<String> = mutableListOf()
        if (accounts.size>0) {
            for (account in accounts) {
                val accounttype = account.type
                val accountname = account.name
                mutableList.add(accounttype + ", " + accountname).toString()
            }
            accountList = mutableList.toList()
        }
    }catch (e:IOException) { }
}
