package icu.nullptr.applistdetector

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import icu.nullptr.applistdetector.component.CheckCard

typealias Detail = MutableCollection<Pair<String, IDetector.Result>>

enum class DetectorCategory(val title: String) {
    SYSTEM("系统环境"),
    NATIVE("底层检测"),
    PACKAGE("应用包管理"),
    FILE("文件检测"),
    HOOK("框架检测"),
    OTHER("杂项")
}

data class DetectorItem(
    val detector: IDetector,
    val category: DetectorCategory,
    var result: IDetector.Result? = null,
    var detail: Detail? = null
)

@Composable
fun MainPage(
    modifier: Modifier,
    viewModel: MainViewModel = viewModel()
) {
    val detectorItems = viewModel.detectorItems

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))

        DetectorCategory.values().forEach { category ->
            val itemsInCategory = detectorItems.filter { it.category == category }
            if (itemsInCategory.isNotEmpty()) {
                CategoryGroup(category.title, itemsInCategory)
            }
        }
        Spacer(Modifier.height(100.dp))
    }
}

@Composable
fun CategoryGroup(title: String, items: List<DetectorItem>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 32.dp, vertical = 4.dp)
        )
        items.forEach { item ->
            CheckCard(
                title = item.detector.name,
                result = item.result,
                detail = item.detail
            )
        }
    }
}
