#include <jni.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>

#if defined(__aarch64__)
#define AT_FDCWD -100
static inline long raw_svc_access(const char* path, int mode) {
    register long x0 __asm__("x0") = (long)AT_FDCWD;
    register long x1 __asm__("x1") = (long)path;
    register long x2 __asm__("x2") = (long)mode;
    register long x8 __asm__("x8") = 48;
    __asm__ __volatile__("svc 0" : "=r"(x0) : "r"(x0), "r"(x1), "r"(x2), "r"(x8) : "memory");
    return x0;
}
#else
#define raw_svc_access access
#endif

extern "C" JNIEXPORT jint JNICALL
Java_icu_nullptr_applistdetector_FileDetection_nativeDetect(JNIEnv* env, jclass, jstring path, jboolean useSyscall) {
    const char* cpath = env->GetStringUTFChars(path, nullptr);
    int result = 0;

    if (raw_svc_access(cpath, F_OK) == 0) {
        result = 3;
    } else {
        if (access(cpath, F_OK) == 0) {
            result = 3;
        }
    }

    env->ReleaseStringUTFChars(path, cpath);
    return result;
}
