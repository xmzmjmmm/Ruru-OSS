APP_ABI := arm64-v8a armeabi-v7a
APP_PLATFORM := android-23
APP_STL := c++_shared
APP_CPPFLAGS := -std=c++17
