package icu.nullptr.applistdetector

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.UUID

class HardwareProbe(context: Context, override val name: String) : IDetector(context) {

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        val alias = "tee_audit_" + UUID.randomUUID().toString()
        return try {
            val kpg = KeyPairGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore"
            )
            
            val builder = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setAttestationChallenge(UUID.randomUUID().toString().toByteArray())

            kpg.initialize(builder.build())
            kpg.generateKeyPair()

            val ks = KeyStore.getInstance("AndroidKeyStore")
            ks.load(null)
            val certificates = ks.getCertificateChain(alias)
            ks.deleteEntry(alias)

            if (certificates == null || certificates.isEmpty()) {
                detail?.add("缺少证书链 (无法验证硬件信任)" to Result.FOUND)
                return Result.FOUND
            }

            val leafCert = certificates[0] as X509Certificate
            val extensionValue = leafCert.getExtensionValue("1.3.6.1.4.1.11129.2.1.17")
            if (extensionValue == null) {
                detail?.add("仅软件级证明 (TEE 已失效)" to Result.FOUND)
                return Result.FOUND
            }

            Result.NOT_FOUND
        } catch (e: Exception) {
            val msg = e.toString()
            if (msg.contains("-36602") || msg.contains("KM_ERROR_CANNOT_ATTEST_IDS") || msg.contains("unauthorized")) {
                detail?.add("TEE 信任链断裂 (KM_ERROR)" to Result.FOUND)
                return Result.FOUND
            }
            Result.NOT_FOUND
        }
    }
}
