package icu.nullptr.applistdetector.component

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import icu.nullptr.applistdetector.IDetector

typealias Detail = MutableCollection<Pair<String, IDetector.Result>>

@Composable
fun CheckCard(
    title: String,
    result: IDetector.Result?,
    detail: Detail?
) {
    var expanded by remember { mutableStateOf(false) }
    
    val resultMap = remember {
        mapOf(
            null to (Icons.Filled.HourglassEmpty to "Pending"),
            IDetector.Result.NOT_FOUND to (Icons.Filled.Done to "Not Found"),
            IDetector.Result.METHOD_UNAVAILABLE to (Icons.Filled.CodeOff to "Unavailable"),
            IDetector.Result.SUSPICIOUS to (Icons.Filled.Visibility to "Suspicious"),
            IDetector.Result.FOUND to (Icons.Filled.Coronavirus to "Found")
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        onClick = { if (result != null) expanded = !expanded }
    ) {
        Column(
            Modifier.padding(all = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    modifier = Modifier.weight(1f)
                )
                
                if (result != null) {
                    val map = resultMap[result]!!
                    Icon(
                        imageVector = map.first,
                        contentDescription = map.second,
                        tint = when (result) {
                            IDetector.Result.FOUND -> Color(0xFFFF3B30)
                            IDetector.Result.SUSPICIOUS -> Color(0xFFFF9500)
                            IDetector.Result.NOT_FOUND -> Color(0xFF34C759)
                            else -> MaterialTheme.colorScheme.onSurface
                        },
                        modifier = Modifier.size(24.dp)
                    )
                    
                    val rotateAngel by animateFloatAsState(if (expanded) 180f else 0f)
                    Icon(
                        imageVector = Icons.Filled.ArrowDropDown,
                        contentDescription = "Expand",
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .rotate(rotateAngel)
                    )
                } else {
                    Box(Modifier.size(24.dp))
                }
            }

            if (expanded && detail != null) {
                Spacer(Modifier.height(16.dp))
                detail.forEach { item ->
                    val map = resultMap[item.second]!!
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.first,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                        Icon(
                            imageVector = map.first,
                            contentDescription = map.second,
                            modifier = Modifier.size(16.dp),
                            tint = when (item.second) {
                                IDetector.Result.FOUND -> Color(0xFFFF3B30)
                                IDetector.Result.SUSPICIOUS -> Color(0xFFFF9500)
                                IDetector.Result.NOT_FOUND -> Color(0xFF34C759)
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }
    }
}
