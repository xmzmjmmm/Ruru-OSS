package icu.nullptr.applistdetector

import android.content.Context
import icu.nullptr.applistdetector.library.R

/**
 *Created by byxiaorun on 2022/8/24/0024.
 */
class SettingProp (
    context: Context, 
    var development_enable: Boolean, 
    var adbenable: Boolean, 
    var vpn_connect: Boolean
) : IDetector(context) {

    override val name = context.getString(R.string.l_sys_feat)

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        var result = Result.NOT_FOUND
        val add: (Pair<String, Result>) -> Unit = {
            result = result.coerceAtLeast(it.second)
            detail?.add(it)
        }
        if (development_enable) {
            add(context.getString(R.string.l_dev_mode) to Result.SUSPICIOUS)
        }
        if (adbenable) {
            add(context.getString(R.string.l_adb_debug) to Result.SUSPICIOUS)
        }
        if (vpn_connect) {
            add(context.getString(R.string.l_vpn_conn) to Result.SUSPICIOUS)
        } else {
            add(context.getString(R.string.l_vpn_not_conn) to Result.NOT_FOUND)
        }
        return result
    }
}
