#ifndef ADVANCED_DETECTOR_H
#define ADVANCED_DETECTOR_H

#include <jni.h>
#include <unistd.h>
#include <sys/syscall.h>

class TimeSideChannelDetector {
public:
    static uint64_t get_ticks();
    static void bind_to_cpu(int cpu_id);
    static uint64_t measure_syscall_time(int syscall_num, const char* path, int cmd, int iterations);
    static bool detect_apatch();
    static bool detect_kernelsu();
    static bool detect_magisk();
    static double analyze_timing_variance();
};

#endif
