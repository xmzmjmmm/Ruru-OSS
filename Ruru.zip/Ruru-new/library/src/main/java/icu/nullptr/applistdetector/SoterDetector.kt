package icu.nullptr.applistdetector

import android.content.Context
import java.lang.reflect.Proxy

class SoterDetector(context: Context, override val name: String) : IDetector(context) {

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        return try {
            val soterCoreClass = Class.forName("com.tencent.soter.core.SoterCore")
            val isNativeSupportMethod = soterCoreClass.getMethod("isNativeSupportSoter")
            val isNativeSupport = isNativeSupportMethod.invoke(null) as Boolean

            val isTrebleConnectedMethod = soterCoreClass.getMethod("isTrebleServiceConnected")
            val isTrebleConnected = isTrebleConnectedMethod.invoke(null) as Boolean

            if (!isNativeSupport || !isTrebleConnected) {
                detail?.add("Soter TEE Anomaly" to Result.FOUND)
                Result.FOUND
            } else {
                Result.NOT_FOUND
            }
        } catch (e: ClassNotFoundException) {
            Result.NOT_FOUND
        } catch (e: Throwable) {
            Result.NOT_FOUND
        }
    }
}
