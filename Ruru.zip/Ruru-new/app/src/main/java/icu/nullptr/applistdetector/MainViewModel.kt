package icu.nullptr.applistdetector

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.byxiaorun.detector.MyApplication.Companion.accList
import com.byxiaorun.detector.MyApplication.Companion.accenable
import com.byxiaorun.detector.MyApplication.Companion.accountList
import com.byxiaorun.detector.MyApplication.Companion.adbenable
import com.byxiaorun.detector.MyApplication.Companion.appContext
import com.byxiaorun.detector.MyApplication.Companion.development_enable
import com.byxiaorun.detector.MyApplication.Companion.vpn_connect
import icu.nullptr.applistdetector.library.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel : ViewModel() {

    private val _detectorItems = mutableStateListOf<DetectorItem>()
    val detectorItems: List<DetectorItem> get() = _detectorItems

    private val basicAppList = listOf(
        "com.topjohnwu.magisk",
        "io.github.vvb2060.magisk",
        "io.github.vvb2060.magisk.lite",
        "com.sukisu.ultra",
        "com.resukisu.resukisu",
        "com.rifsxd.ksunext",
        "me.weishu.kernelsu",
        "me.garfieldhan.apatch.next",
        "de.robv.android.xposed.installer",
        "org.meowcat.edxposed.manager",
        "org.lsposed.manager",
        "top.canyie.dreamland.manager",
        "me.weishu.exp",
        "com.tsng.hidemyapplist",
        "cn.geektang.privacyspace",
        "moe.shizuku.redirectstorage",
        "lrknem.zsfolt.jgovyb",
        "trrovy.gghgte.swdool",
        "com.kdrag0n.safetynetfix",
        "top.canyie.shamiko",
        "com.saurik.substrate",
        "com.devadvance.rootcloak",
        "com.devadvance.rootcloakplus",
        "com.formyhalos.hide_my_root",
        "com.amaze.reader"
    )

    init {
        initDetectors()
        runAllDetectors()
    }

    private fun initDetectors() {
        if (_detectorItems.isNotEmpty()) return
        _detectorItems.addAll(listOf(
            DetectorItem(AbnormalEnvironment(appContext, appContext.getString(R.string.d_abnormal_env)), DetectorCategory.SYSTEM),
            DetectorItem(HardwareProbe(appContext, "硬件密钥证明"), DetectorCategory.SYSTEM),
            DetectorItem(SoterDetector(appContext, "TEE 安全检测"), DetectorCategory.SYSTEM),
            DetectorItem(SettingProp(appContext, development_enable, adbenable, vpn_connect), DetectorCategory.SYSTEM),
            DetectorItem(FileDetection(appContext, true, appContext.getString(R.string.d_file_syscall)), DetectorCategory.NATIVE),
            DetectorItem(TimeSideChannelDetector(appContext, appContext.getString(R.string.l_tc)), DetectorCategory.NATIVE),

            DetectorItem(PackageDetector(appContext, appContext.getString(R.string.d_pkg_name)), DetectorCategory.PACKAGE),
            DetectorItem(PMCommand(appContext, "PM 命令特征"), DetectorCategory.PACKAGE),
            DetectorItem(PMConventionalAPIs(appContext, "应用查询"), DetectorCategory.PACKAGE),
            DetectorItem(PMSundryAPIs(appContext, "杂项查询"), DetectorCategory.PACKAGE),
            DetectorItem(PMQueryIntentActivities(appContext, "意图扫描"), DetectorCategory.PACKAGE),
            
            DetectorItem(FileDetection(appContext, false, appContext.getString(R.string.l_fl)), DetectorCategory.FILE),
            
            DetectorItem(XposedModules(appContext, appContext.getString(R.string.l_xp), false), DetectorCategory.HOOK),
            
            DetectorItem(MagiskApp(appContext, appContext.getString(R.string.d_magisk_name)), DetectorCategory.OTHER),
            DetectorItem(Accessibility(appContext, accList, accenable, appContext.getString(R.string.d_accessibility)), DetectorCategory.OTHER),
            DetectorItem(Account(appContext, accountList, "系统账户"), DetectorCategory.OTHER)
        ))
    }

    fun runAllDetectors() {
        _detectorItems.forEachIndexed { index, _ ->
            viewModelScope.launch {
                runDetectorItem(index)
            }
        }
    }

    private suspend fun runDetectorItem(id: Int) {
        val item = _detectorItems.getOrNull(id) ?: return
        val packages = when (item.category) {
            DetectorCategory.PACKAGE, DetectorCategory.FILE, DetectorCategory.NATIVE -> basicAppList
            else -> null
        }
        val detail = mutableListOf<Pair<String, IDetector.Result>>()
        val result = withContext(Dispatchers.IO) {
            item.detector.run(packages, detail)
        }
        _detectorItems[id] = item.copy(result = result, detail = detail)
    }
}
