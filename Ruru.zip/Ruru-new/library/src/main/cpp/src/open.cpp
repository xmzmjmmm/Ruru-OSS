
#include "open.h"

open::open(const char *path, int i) {

}
