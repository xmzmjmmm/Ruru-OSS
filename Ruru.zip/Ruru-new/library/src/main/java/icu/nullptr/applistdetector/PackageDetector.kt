package icu.nullptr.applistdetector

import android.content.Context
import icu.nullptr.applistdetector.library.R

class PackageDetector(context: Context, override val name: String) : IDetector(context) {

    private val packageGroups = mapOf(
        context.getString(R.string.g_root_tools) to listOf(
            "com.topjohnwu.magisk",
            "eu.chainfire.supersu",
            "com.kingroot.kinguser",
            "com.noshufou.android.su",
            "com.koushikdutta.superuser",
            "com.thirdparty.superuser",
            "com.yellowes.su",
            "com.gears42.pureroot",
            "com.formyhm.hideroot"
        ),
        context.getString(R.string.g_hook_tools) to listOf(
            "de.robv.android.xposed.installer",
            "org.meowcat.edxposed.manager",
            "org.lsposed.manager",
            "com.chelpus.luckypatcher",
            "com.saurik.substrate",
            "cc.madkite.freedom",
            "com.solohsu.android.edxp.manager",
            "com.zhihuimanwu.tiannoshu",
            "com.topjohnwu.zygisk"
        ),
        context.getString(R.string.g_root_hide) to listOf(
            "com.devadvance.rootcloak",
            "com.devadvance.rootcloakplus",
            "com.amphoras.hidemyroot",
            "com.amphoras.hidemyrootadfree",
            "com.zacharee1.systemuituner"
        ),
        context.getString(R.string.g_audit_tools) to listOf(
            "com.qihoo.permmgr",
            "com.kingo.root",
            "com.iroot.mobile",
            "com.vroot.master",
            "com.dianxinos.superuser",
            "com.zhuoyi.root",
            "com.tencent.danmaku",
            "com.lbe.security.miui",
            "com.miui.securitycenter"
        )
    )

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        var result = Result.NOT_FOUND
        val pm = context.packageManager

        for ((groupName, pkgList) in packageGroups) {
            for (pkg in pkgList) {
                val isInstalled = try {
                    pm.getPackageInfo(pkg, 0)
                    true
                } catch (e: Exception) {
                    false
                }

                val hasDataDir = FileDetection.detect("/data/data/$pkg", true) == Result.FOUND

                if (isInstalled || hasDataDir) {
                    val status = if (isInstalled && hasDataDir) Result.FOUND else Result.SUSPICIOUS
                    detail?.add("$groupName ($pkg)" to status)
                    result = result.coerceAtLeast(status)
                }
            }
        }

        return result
    }
}
