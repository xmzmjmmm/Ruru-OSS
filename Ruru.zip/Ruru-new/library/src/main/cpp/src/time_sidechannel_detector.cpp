#include <jni.h>
#include <sched.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <csignal>
#include <cerrno>
#include <ctime>

#if defined(__aarch64__)
    #define SYS_GETPID 172
    #define SYS_OPENAT 56
    #define SYS_FACCESSAT 48
    #define SYS_TRUNCATE 45
#elif defined(__arm__)
    #define SYS_GETPID 20
    #define SYS_OPENAT 322
    #define SYS_ACCESS 33
    #define SYS_FACCESSAT 327
    #define SYS_TRUNCATE 37
#elif defined(__i386__)
    #define SYS_GETPID 20
    #define SYS_OPENAT 295
    #define SYS_ACCESS 33
    #define SYS_FACCESSAT 307
    #define SYS_TRUNCATE 37
#elif defined(__x86_64__)
    #define SYS_GETPID 39
    #define SYS_OPENAT 257
    #define SYS_ACCESS 21
    #define SYS_TRUNCATE 76
#else
    #error "Unsupported architecture"
#endif

#ifndef AT_FDCWD
#define AT_FDCWD (-100)
#endif

static inline uint64_t get_ticks() {
    uint64_t v;
#if defined(__aarch64__)
    asm volatile("isb; mrs %0, cntvct_el0; isb" : "=r"(v) : : "memory");
#elif defined(__x86_64__)
    uint32_t low, high;
    asm volatile("rdtsc" : "=a"(low), "=d"(high));
    v = ((uint64_t)high << 32) | low;
#elif defined(__i386__)
    asm volatile("rdtsc" : "=A"(v));
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    v = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
    return v;
}

static void bind_to_cpu(int cpu_id) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(cpu_id, &cpuset);
    sched_setaffinity(0, sizeof(cpu_set_t), &cpuset);
}

static inline long my_openat(const char* path, int flags) {
    return syscall(SYS_OPENAT, AT_FDCWD, path, flags, 0);
}

static inline long my_truncate(const char* path, long length) {
    return syscall(SYS_TRUNCATE, path, length);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_TimeSideChannelDetector_nativeDetectAPatch(JNIEnv* env, jobject thiz) {
    bind_to_cpu(0);
    const int ITERATIONS = 10000;
    const char* target_path = "/system/bin/sh";

    auto measure_truncate = [&](const char* p, long l) {
        uint64_t start = get_ticks();
        for (int i = 0; i < ITERATIONS; i++) my_truncate(p, l);
        return (get_ticks() - start) / ITERATIONS;
    };

    uint64_t deep_time = 0;
    for (int i = 0; i < 5; i++) deep_time += measure_truncate(target_path, 0x7FFFFFFF - i);
    deep_time /= 5;

    uint64_t shallow_time = 0;
    for (int i = 0; i < 5; i++) shallow_time += measure_truncate(target_path, 1 + i);
    shallow_time /= 5;

    if (deep_time == 0 || shallow_time == 0) return JNI_FALSE;
    uint64_t diff = deep_time > shallow_time ? deep_time - shallow_time : shallow_time - deep_time;
    double avg = (double)(deep_time + shallow_time) / 2.0;
    return (diff / avg) * 100.0 > 20.0 ? JNI_TRUE : JNI_FALSE;
}

static void calculate_stats(const std::vector<uint64_t>& data, double& mean, double& stddev) {
    if (data.empty()) return;
    double sum = 0;
    for (uint64_t v : data) sum += v;
    mean = sum / data.size();
    double var = 0;
    for (uint64_t v : data) var += pow((double)v - mean, 2);
    stddev = sqrt(var / data.size());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_TimeSideChannelDetector_nativeDetectKernelSU(JNIEnv* env, jobject thiz) {
    bind_to_cpu(0);
    const int ITERATIONS = 2000;
    const char* test_paths[] = {"/data/adb/ksu", "/dev/kernelsu", "/proc/kernelsu", "/sys/kernel/ksu", "/data/adb/apatch", nullptr};
    
    auto get_samples = [&](const char* p, std::vector<uint64_t>& samples) {
        for(int i=0; i<50; i++) {
            uint64_t start = get_ticks();
            long res = my_openat(p, O_RDONLY);
            if (res >= 0) close(res);
            samples.push_back(get_ticks() - start);
        }
    };

    std::vector<uint64_t> baseline_samples;
    get_samples("/system/build.prop", baseline_samples);
    get_samples("/proc/self/maps", baseline_samples);
    
    double b_mean, b_stddev;
    calculate_stats(baseline_samples, b_mean, b_stddev);

    for (int i = 0; test_paths[i]; i++) {
        std::vector<uint64_t> test_samples;
        get_samples(test_paths[i], test_samples);
        double t_mean, t_stddev;
        calculate_stats(test_samples, t_mean, t_stddev);

        if (t_mean > b_mean + 8 * b_stddev && t_mean > b_mean * 5) return JNI_TRUE;
    }
    return JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_icu_nullptr_applistdetector_TimeSideChannelDetector_nativeDetectMagisk(JNIEnv* env, jobject thiz) {
    bind_to_cpu(0);
    const int ITERATIONS = 8000;
    const char* magisk_paths[] = {"/data/adb/magisk", "/sbin/.magisk", "/dev/.magisk", "/data/adb/modules", "/data/adb/magisk.db", nullptr};
    
    auto measure_open = [&](const char* p) {
        uint64_t start = get_ticks();
        for (int i = 0; i < ITERATIONS; i++) my_openat(p, O_RDONLY);
        return (get_ticks() - start) / ITERATIONS;
    };

    uint64_t baseline = measure_open("/system/lib/libc.so");
    if (baseline == 0) baseline = 1;
    
    for (int i = 0; magisk_paths[i]; i++) {
        if (measure_open(magisk_paths[i]) > baseline * 3) return JNI_TRUE;
    }
    return JNI_FALSE;
}

extern "C" JNIEXPORT jdouble JNICALL
Java_icu_nullptr_applistdetector_TimeSideChannelDetector_nativeAnalyzeTiming(JNIEnv* env, jobject thiz) {
    bind_to_cpu(0);
    const int SAMPLES = 1000;
    const int CHECKS = 3;
    std::vector<double> cv_results;

    for (int check = 0; check < CHECKS; check++) {
        std::vector<uint64_t> timings;
        for (int i = 0; i < SAMPLES; i++) {
            uint64_t start = get_ticks();
            syscall(SYS_GETPID);
            timings.push_back(get_ticks() - start);
        }
        std::sort(timings.begin(), timings.end());
        int trim = SAMPLES / 10;
        double sum = 0;
        int count = SAMPLES - 2 * trim;
        for (int i = trim; i < SAMPLES - trim; i++) sum += (double)timings[i];
        double mean = sum / count;
        if (mean <= 0) { cv_results.push_back(0); continue; }
        double var = 0;
        for (int i = trim; i < SAMPLES - trim; i++) var += pow((double)timings[i] - mean, 2);
        double cv = sqrt(var / count) / mean;
        cv_results.push_back(std::isnan(cv) ? 0 : cv);
    }
    std::sort(cv_results.begin(), cv_results.end());
    if (cv_results.size() < 3) return 0;
    if (cv_results[2] - cv_results[0] > 0.1) return 0;
    return cv_results[1];
}
