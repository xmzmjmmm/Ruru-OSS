
#ifndef DETECTOR_OPEN_H
#define DETECTOR_OPEN_H


class open {

public:
    open(const char *path, int i);
};


#endif
