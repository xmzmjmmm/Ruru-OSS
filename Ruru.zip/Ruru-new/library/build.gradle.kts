val minSdkVer: Int by rootProject.extra
val targetSdkVer: Int by rootProject.extra
val compileSdkVer: Int by rootProject.extra
val ndkVer: String by rootProject.extra
val javaVer: JavaVersion by rootProject.extra

plugins {
    id("com.android.library")
    kotlin("android")
}

android {
    namespace = "icu.nullptr.applistdetector.library"
    compileSdk = compileSdkVer
    ndkVersion = ndkVer

    buildFeatures {
        prefab = true
    }

    defaultConfig {
        minSdk = minSdkVer
        targetSdk = targetSdkVer

        externalNativeBuild.cmake {
            arguments += "-DANDROID_STL=c++_shared"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            consumerProguardFiles("proguard-rules.pro")
            packaging {
                jniLibs {
                    keepDebugSymbols.add("**/*.so")
                }
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "4.1.2"
        }
    }

    compileOptions {
        sourceCompatibility = javaVer
        targetCompatibility = javaVer
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.annotation:annotation:1.7.1")
    implementation("com.android.tools.build:apkzlib:7.2.2")
    implementation("io.github.vvb2060.ndk:xposeddetector:2.2")
    implementation("com.github.Tencent.soter:soter-wrapper:2.1.19.2")
    implementation("com.github.Tencent.soter:soter-core:2.1.19.2")
}
