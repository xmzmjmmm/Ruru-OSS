package icu.nullptr.applistdetector

import android.content.Context
import androidx.annotation.Keep

@Keep
class TimeSideChannelDetector(context: Context, override val name: String) : IDetector(context) {
    
    companion object {
        init {
            System.loadLibrary("applist_detector")
        }
    }
    
    @Keep
    private external fun nativeDetectAPatch(): Boolean
    @Keep
    private external fun nativeDetectKernelSU(): Boolean
    @Keep
    private external fun nativeDetectMagisk(): Boolean
    @Keep
    private external fun nativeAnalyzeTiming(): Double

    override fun run(packages: Collection<String>?, detail: Detail?): Result {
        var result = Result.NOT_FOUND
        val add: (Pair<String, Result>) -> Unit = {
            result = result.coerceAtLeast(it.second)
            detail?.add(it)
        }


        val timingCV = try {
            nativeAnalyzeTiming()
        } catch (_: Exception) {
            0.0
        }

        add("侧信道" to when {
            timingCV == 0.0 -> Result.NOT_FOUND
            timingCV > 0.6 -> Result.FOUND
            timingCV > 0.4 -> Result.SUSPICIOUS
            else -> Result.NOT_FOUND
        })
        

        val apatchDetected = nativeDetectAPatch()
        val kernelsuDetected = nativeDetectKernelSU()
        val magiskDetected = nativeDetectMagisk()
        add("内核Root" to if (apatchDetected || kernelsuDetected) Result.FOUND else Result.NOT_FOUND)
        add("Magisk/Zygisk" to if (magiskDetected) Result.SUSPICIOUS else Result.NOT_FOUND)

        val rootScore = listOf(apatchDetected, kernelsuDetected, magiskDetected).count { it }
        add("异常环境" to when {
            rootScore >= 2 -> Result.FOUND
            rootScore == 1 -> Result.SUSPICIOUS
            else -> Result.NOT_FOUND
        })
        
        return result
    }
}